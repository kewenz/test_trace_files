#!/public/home/anaconda3/bin/python
## =============================================================================
#$ -j n
#$ -notify
#$ -l ct=48:00:00
#$ -l vmem=2.0G
#$ -l fsize=3.0G
#$ -l sps=1
## =============================================================================
import os
import subprocess
import datetime
now=datetime.datetime.now()
with open("Stshp_MZS_QGS204JET_Proton_3.98_79.6_90.0_9.status",'a') as f:
  f.write(str(now)+" Running\n")
wd = os.getcwd()
print(wd)
cmd="/public/home/Mapengxiong_PMO/aires/bin/ZHAireSQIIr04<Stshp_MZS_QGS204JET_Proton_3.98_79.6_90.0_9.inp>Stshp_MZS_QGS204JET_Proton_3.98_79.6_90.0_9.stdout"
p = subprocess.Popen(cmd,cwd=wd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
stdout,stderr=p.communicate()
now=datetime.datetime.now()
with open("Stshp_MZS_QGS204JET_Proton_3.98_79.6_90.0_9.status",'a') as f:
  f.write(str(now)+" RunComplete\n")
